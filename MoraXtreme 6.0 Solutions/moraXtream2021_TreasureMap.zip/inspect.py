input_data = """
6
1 44
2 44
3 44
4 44
5 44
6 44
6
1 2 10
2 3 10
3 4 10
4 5 10
5 6 10
6 1 10
1
"""


class Road:

    def __init__(self, size):
        self.road_map = [[None] * size for _ in range(size)]
        self.total = 0

    def add(self, f, t, cost):
        self.road_map[f - 1][t - 1] = self.road_map[t - 1][f - 1] = cost
        self.total += cost

    def get(self, f, t):
        return self.road_map[f - 1][t - 1]

    def possible_visits(self, f):
        return tuple(filter(lambda road: road[1] is not None, enumerate(self.road_map[f - 1], start=1)))


def parse_input(inp):
    lines = inp.strip('\n').split('\n')
    n_places = int(lines[0])
    places = tuple(int(line.strip().split()[1])
                   for line in lines[1:n_places + 1])
    # n_roads = int(lines[n_places + 1])
    roads = Road(n_places)
    for line in lines[n_places + 2:-1]:
        values = tuple(map(int, line.split()))
        roads.add(*values)
    return n_places, places, roads, int(lines[-1])


def visit_to(config, to):
    return tuple((0 if i + 1 == to else config[i]) for i in range(N))


def low_cost_sort_possible_visits(visits):
    return tuple(sorted(visits, key=lambda vis: vis[1]))


def max_coin_sort_possible_visits(visits, config):
    return tuple(sorted(visits, key=lambda vis: config[vis[0]-1], reverse=True))


def get_max_coins(config, current_position, coins, path):
    global max_coins, max_coins_path
    if not any(config):
        return
    possible_visits = road_map.possible_visits(current_position)
    for pos, cost in max_coin_sort_possible_visits(possible_visits, config):
        if coins >= cost:
            new_coins = coins - cost + config[pos - 1]
            new_path = (*path, pos)
            if new_coins > max_coins:
                max_coins = new_coins
                max_coins_path = new_path
            get_max_coins(visit_to(config, pos), pos, new_coins, new_path)


N, start_config, road_map, start_position = parse_input(input_data)
max_coins = start_config[start_position - 1]
max_coins_path = (start_position,)

get_max_coins(visit_to(start_config, start_position),
              start_position, max_coins, (start_position,))
print(max_coins)
print(max_coins_path)
