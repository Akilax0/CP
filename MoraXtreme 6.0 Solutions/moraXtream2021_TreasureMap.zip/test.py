class Road:

    def __init__(self, size):
        self.road_map = [[None] * size for _ in range(size)]
        self.total = 0

    def add(self, f, t, cost):
        self.road_map[f - 1][t - 1] = self.road_map[t - 1][f - 1] = cost
        self.total += cost

    def get(self, f, t):
        return self.road_map[f - 1][t - 1]

    def possible_visits(self, f):
        return tuple(filter(lambda road: road[1] is not None, enumerate(self.road_map[f - 1], start=1)))

def parse_input():
    n_places = int(input())
    places = tuple(int(input().strip().split()[1]) for line in range(n_places))
    n_roads = int(input())
    roads = Road(n_places)
    for line in range(n_roads):
        values = tuple(map(int, input().split()))
        roads.add(*values)
    return n_places, places, roads, int(input())


def visit_to(config, to):
    return tuple((0 if i + 1 == to else config[i]) for i in range(N))


def low_cost_sort_possible_visits(visits):
    return tuple(sorted(visits, key=lambda vis: vis[1]))


def max_coin_sort_possible_visits(visits, config):
    return tuple(sorted(visits, key=lambda vis: config[vis[0] - 1], reverse=True))


def get_max_coins(config, current_position, coins):
    global max_coins
    if not any(config):
        return
    possible_visits = road_map.possible_visits(current_position)
    for pos, cost in max_coin_sort_possible_visits(possible_visits, config):
        if coins >= cost:
            new_coins = coins - cost + config[pos - 1]
            if new_coins > max_coins:
                max_coins = new_coins
            get_max_coins(visit_to(config, pos), pos, new_coins)


N, start_config, road_map, start_position = parse_input()
max_coins = start_config[start_position - 1]

get_max_coins(visit_to(start_config, start_position), start_position, max_coins)
print(max_coins)
